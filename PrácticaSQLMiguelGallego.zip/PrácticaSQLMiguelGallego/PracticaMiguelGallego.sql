
-- Schema cration
create schema kc_vehicles authorization ppoembtx;

-- Tables creation
create table kc_vehicles.Cars(
	id_car varchar(10) not null,
	color varchar(20) not null,
	licence_plate varchar(20) not null,
	total_kilometers int not null,
	policy_number varchar(10) not null,
	buy_date date not null,
	deregister_date date null,
	id_insurance_company varchar(10) not null,
	id_model varchar(10) not null
);

create table kc_vehicles.Inspections(
	id_inspection varchar(10) not null,
	kilometers int not null,
	amount int null,
	inspection_date date not null,
	id_car varchar(10) not null,
	id_currency varchar(10) not null
);

create table kc_vehicles.Currencies(
	id_currency varchar(10) not null,
	currency_type varchar(30) not null
);

create table kc_vehicles.Insurance_Companies(
	id_insurance_company varchar(10) not null,
	company_name varchar(30) not null
);

create table kc_vehicles.Models(
	id_model varchar(10) not null,
	model_name varchar(30) not null,
	id_brand varchar(10) not null
);

create table kc_vehicles.Brands(
	id_brand varchar(10) not null,
	brand_name varchar(30) not null,
	id_bussines_group varchar(10)
);

create table kc_vehicles.Bussines_Groups(
	id_bussines_group varchar(10) not null,
	bussines_group_name varchar(64) not null
);

-- Primary Keys
alter table kc_vehicles.Cars
add constraint cars_PK primary key (id_car);

alter table kc_vehicles.Inspections
add constraint inspections_PK primary key(id_inspection);

alter table kc_vehicles.Currencies
add constraint currencies_PK primary key (id_currency);

alter table kc_vehicles.Insurance_Companies
add constraint insurance_companies_PK primary key(id_insurance_company);

alter table kc_vehicles.Models
add constraint models_PK primary key (id_model);
alter table kc_vehicles.Brands
add constraint brands_PK primary key (id_brand);

alter table kc_vehicles.Bussines_Groups
add constraint bussines_groups_PK primary key(id_bussines_group);

-- Foreing Keys
alter table kc_vehicles.Cars
add constraint cars_insurance_companies_FK foreign key (id_insurance_company)
references kc_vehicles.Insurance_companies(id_insurance_company);

alter table kc_vehicles.Cars
add constraint cars_model_FK foreign key (id_model)
references kc_vehicles.Models(id_model);

alter table kc_vehicles.Inspections
add constraint inspections_cars_FK foreign key (id_car)
references kc_vehicles.Cars(id_car);

alter table kc_vehicles.Inspections
add constraint currencies_cars_FK foreign key (id_currency)
references kc_vehicles.Currencies(id_currency);

alter table kc_vehicles.Models
add constraint models_brands_FK foreign key (id_brand)
references kc_vehicles.Brands(id_brand);

alter table kc_vehicles.Brands
add constraint brands_bussines_group_FK foreign key (id_bussines_group)
references kc_vehicles.Bussines_Groups(id_bussines_group);

-- Data inserts
insert into kc_vehicles.bussines_groups(id_bussines_group, bussines_group_name)
values('1','Volkswagen Group');insert into kc_vehicles.bussines_groups(id_bussines_group, bussines_group_name)
values('2','Toyota Group');insert into kc_vehicles.bussines_groups(id_bussines_group, bussines_group_name)
values('3','General Motors (GM)');

insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('1','Volkswagen', '1');
insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('2','Audi', '1');
insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('3','Toyota', '2');
insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('4','Lexus', '2');
insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('5','Chevrolet', '3');
insert into kc_vehicles.brands (id_brand, brand_name, id_bussines_group)
values('6','Cadillac', '3');

insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('1','Golf', '1');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('2','Tiguan', '1');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('3','A4', '2');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('4','Q6', '2');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('5','Collora', '3');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('6','Yaris', '3');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('7','rx', '4');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('8','Camaro', '5');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('9','Cruze', '5');
insert into kc_vehicles.models  (id_model, model_name , id_brand)
values('10','Escalade', '6');

insert into kc_vehicles.insurance_companies  (id_insurance_company, company_name)
values('1','Mapfre');
insert into kc_vehicles.insurance_companies  (id_insurance_company, company_name)
values('2','Allianz');
insert into kc_vehicles.insurance_companies  (id_insurance_company, company_name)
values('3','AXA');

insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('1','Red', '1234NKL', 20456, 'ESP123456A', '05-02-2022', '1', '1');
insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('2','Blue', '4567DVF', 679034, 'ESP789012C', '10-03-2013', '2', '5');
insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('3','Green', '8552FOP', 357890, 'ESP345678B', '12-15-2019', '3', '10');
insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('4','White', '2198ASD', 121345, 'ESP456789D', '09-18-2004', '3', '7');
insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('5','Yellow', '5108MHG', 54321, 'ESP234567E', '10-21-2001', '1', '3');
insert into kc_vehicles.cars (id_car, color, licence_plate, total_kilometers, policy_number, buy_date, id_insurance_company, id_model)
values('6','Black', '4897SDE', 184678, 'ESP123456F', '06-27-2021', '2', '2');

insert into kc_vehicles.currencies (id_currency, currency_type)
values('1','Euro');
insert into kc_vehicles.currencies (id_currency, currency_type)
values('2','Dollar');
insert into kc_vehicles.currencies (id_currency, currency_type)
values('3','Pound');

insert into kc_vehicles.inspections (id_inspection, kilometers, amount, inspection_date, id_car, id_currency)
values('1',19234, 50, '04-12-2022', '6', '1');
insert into kc_vehicles.inspections (id_inspection, kilometers, amount, inspection_date, id_car, id_currency)
values('2',25567, 50, '12-19-2022', '6', '1');
insert into kc_vehicles.inspections (id_inspection, kilometers, amount, inspection_date, id_car, id_currency)
values('3',22456, 55, '06-22-2009', '4', '3');
insert into kc_vehicles.inspections (id_inspection, kilometers, amount, inspection_date, id_car, id_currency)
values('4',70518, 60, '05-02-2023', '1', '2');

select id_car, model_name, brand_name, bussines_group_name, buy_date, licence_plate, color, total_kilometers, company_name, policy_number
from kc_vehicles.cars c 
join kc_vehicles.insurance_companies ic 
on c.id_insurance_company = ic.id_insurance_company 
join kc_vehicles.models m 
on m.id_model = c.id_model
join kc_vehicles.brands b 
on m.id_brand = b.id_brand
join kc_vehicles.bussines_groups bg 
on b.id_bussines_group = bg.id_bussines_group
where c.deregister_date isnull;
